import execute
dns_script = execute.dns_altering_script()
dns_script.get_cloud_provider()
dns_script.execute()
dns_script.set_dns_attribute()